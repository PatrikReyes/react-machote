import { Card } from "antd";
import React from "react";

export const Home = () => {
  return (
    <>
      <div style={{ backgroundColor: "red" }}>Algo por aqui</div>
    </>
  );
};
