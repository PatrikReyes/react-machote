import React from "react";

export const Empleados = () => {
  return <div>Empleados</div>;
};
