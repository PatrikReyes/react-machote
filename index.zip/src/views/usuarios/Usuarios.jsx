import React from "react";

export const Usuarios = () => {
  return <div>Usuarios</div>;
};
