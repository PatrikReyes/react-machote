const urlBase = "https://localhost:44303/api";

export const URL_LOGIN = `${urlBase}/Login`;
