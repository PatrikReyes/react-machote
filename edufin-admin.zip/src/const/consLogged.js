export const consLogged = {
    STARTING: 'starting',
    LOGGED: 'logged',
    NOTLOGGED: 'not logged'
}