import React from 'react'
import CardPage from '../../layout/CardPage'

export const Usuarios = () => {
  return (
    <CardPage titulo="Usuarios" >
    
    
  </CardPage>
  )
}
