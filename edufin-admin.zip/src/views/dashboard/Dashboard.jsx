import React from "react";
import CardPage from "../../layout/CardPage";

export const Dashboard = () => {
  return (
    <CardPage titulo="Dashboard" >
      
      
    </CardPage>
  );
};
