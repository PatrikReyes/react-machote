import React from 'react'
import CardPage from '../../layout/CardPage'

export const Conntenidos = () => {
  return (
    <CardPage titulo="Contenidos" >
    
  </CardPage>
  )
}
