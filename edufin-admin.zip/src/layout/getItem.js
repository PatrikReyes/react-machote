export function getItem(label, key, icon, children) {
  return {
    key,
    icon,
    children,
    label,
  };
}
