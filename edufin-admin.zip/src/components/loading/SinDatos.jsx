import React from "react";

export const SinDatos = ({ style }) => {
  return (
    <div style={{ marginTop: 20, marginLeft: 10, color: "#ccc", ...style }}>
      Sin datos
    </div>
  );
};
