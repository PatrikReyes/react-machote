window["runConfig"] = {
  ambiente: "Dev",
  URL_BASE: "https://back8.impulsafinanzas.com",
};
